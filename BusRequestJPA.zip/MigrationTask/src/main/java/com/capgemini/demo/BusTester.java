package com.capgemini.demo;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BusTester {

	public static void main(String[] args) {
		
		
EntityManagerFactory emf=Persistence.createEntityManagerFactory("PERSISTENCE");
		
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		entityTransaction.begin();
		
		LoginBean loginBean=new LoginBean("ram","ram123");
		PassRequestBean passRequestBean=new PassRequestBean("1234_SE","ram","reddy", "Male","Chennai","ram@cap.com",LocalDate.of(2018, 9, 17) ,"Chennai-MIPL", "Tambaram",
				LocalTime.of(9, 30),"Manager");
		RouteBean routeBean=new
		RouteBean("Mipl,Spkoil,MaraimaliNagar,Tambaram", "Mipl-Tambaram",50,20,"TN1234",
				"8975642311",42);
		 TransactionBean transaction=new TransactionBean(1,"1234_SE", LocalDate.now(),45.0,500);

		 entityManager.persist(loginBean);
		 entityManager.persist(passRequestBean);
		 entityManager.persist(routeBean);
		 entityManager.persist(transaction);
		 
		 entityTransaction.commit();
		 entityManager.close();
		 
	}

}
