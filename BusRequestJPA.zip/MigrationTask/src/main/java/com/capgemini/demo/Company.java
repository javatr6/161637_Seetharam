package com.capgemini.demo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Company {
	
	@Id
	@GeneratedValue
	private int CompanyId;
	private String CompanyName;
	
	@OneToMany(mappedBy="company",targetEntity=Employee.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Employee> empList=new ArrayList<>();
	
	public Company() {
		
	}

	public Company(String companyName) {
		super();
		
		CompanyName = companyName;
	}

	public Company(int companyId, String companyName, List<Employee> empList) {
		super();
		CompanyId = companyId;
		CompanyName = companyName;
		this.empList = empList;
	}

	

	public int getCompanyId() {
		return CompanyId;
	}

	public void setCompanyId(int companyId) {
		CompanyId = companyId;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public List<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	@Override
	public String toString() {
		return "Company [CompanyId=" + CompanyId + ", CompanyName=" + CompanyName + ", empList=" + empList + "]";
	}

	

}
