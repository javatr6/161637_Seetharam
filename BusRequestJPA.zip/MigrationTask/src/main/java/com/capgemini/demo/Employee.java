package com.capgemini.demo;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {
	
	@Id
	private int EmployeeId;
	private String EmployeeName;
	private LocalDate doj;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="companyFK")
	private Company company;
	
	public Employee() {
		
	}

	public Employee(int employeeId, String employeeName, Company company) {
		super();
		EmployeeId = employeeId;
		EmployeeName = employeeName;
		this.company = company;
	}

	public Employee(int employeeId, String employeeName, LocalDate doj, Company company) {
		super();
		EmployeeId = employeeId;
		EmployeeName = employeeName;
		this.doj = doj;
		this.company = company;
	}

	public LocalDate getDoj() {
		return doj;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	public int getEmployeeId() {
		return EmployeeId;
	}

	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}

	public String getEmployeeName() {
		return EmployeeName;
	}

	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@Override
	public String toString() {
		return "Employee [EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName + ", doj=" + doj + ", company="
				+ company + "]";
	}

}
