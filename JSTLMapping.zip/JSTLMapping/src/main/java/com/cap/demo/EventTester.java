package com.cap.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class EventTester {

	public static void main(String[] args) {
EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		entityTransaction.begin();

		Events servlets=new Events("123","servlets");
		Events python=new Events("456","python");
		Events iot=new Events("789","iot");
		
		Delegates delagates1=new Delegates(1,"sai");
		Delegates delagates2=new Delegates(2,"ram");
		Delegates delagates3=new Delegates(3,"krishna");
		Delegates delagates4=new Delegates(51,"seetha");
		Delegates delagates5=new Delegates(16,"john");
		Delegates delagates6=new Delegates(71,"tom");
		
		
		
		delagates1.getEvents().add(servlets);
		delagates1.getEvents().add(iot);
		delagates2.getEvents().add(python);
		delagates3.getEvents().add(iot);
		delagates3.getEvents().add(servlets);
		delagates4.getEvents().add(python);
		delagates5.getEvents().add(iot);
		delagates6.getEvents().add(servlets);
		delagates5.getEvents().add(python);
		
		entityManager.persist(delagates1);
		entityManager.persist(delagates2);
		entityManager.persist(delagates3);
		entityManager.persist(delagates4);
		entityManager.persist(delagates5);
		entityManager.persist(delagates6);
		entityManager.persist(servlets);
		entityManager.persist(python);
		entityManager.persist(iot);
		
		entityTransaction.commit();
		entityManager.close();

	}

}
