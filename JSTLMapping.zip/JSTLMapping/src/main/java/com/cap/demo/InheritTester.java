package com.cap.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InheritTester {

	public static void main(String[] args) {
		
EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		entityTransaction.begin();
		
		Project p=new Project(1001,"CITI BANK");
		
		Module m=new Module();
		m.setProjectId(1234);
		m.setProjectName("Discover");
		m.setModuleName("Login Module");
		
		Task t=new Task();
		t.setProjectId(1235);
		t.setProjectName("Completing Transaction");
		t.setModuleName("Signing in..");
		t.setTaskName("Debit Money");
		
		
		entityManager.persist(p);
		entityManager.persist(m);
		entityManager.persist(t);
	
		entityTransaction.commit();
		entityManager.close();

	}

}
