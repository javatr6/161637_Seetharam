package com.capgemini.demo;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainDemo {
	public static void main(String args[]) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("PERSISTENCE");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		entityTransaction.begin();
		
		Company capg=new Company("Cap Gemini Services Limited");
		Company tcs=new Company("TATA Consultency Services Limited");
		
		
		Employee ram=new Employee(1001,"ram",capg);
		ram.setDoj(LocalDate.now());
		Employee srinu=new Employee(1002,"srinu",tcs);
		srinu.setDoj(LocalDate.of(2018,9,19));
		
		entityManager.persist(capg);
		entityManager.persist(tcs);
		entityManager.persist(ram);
		entityManager.persist(srinu);
		
		
		entityTransaction.commit();
		entityManager.close();

	}

}
