package org.cap.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.BusPassRequestBean;


@WebServlet("/PassRequestServlet")
public class PassRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	   
    public PassRequestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String employeeid=request.getParameter("employeeid");
			String firstname=request.getParameter("firstname");
			String lastname=request.getParameter("lastname");
			String gender=request.getParameter("gender");
			String address=request.getParameter("address");
			String email=request.getParameter("email");
			String location=request.getParameter("location");
		String doj=request.getParameter("doj");
			
			String pickUpLoc=request.getParameter("pickUpLoc");
			String pickUpTime=request.getParameter("pickUpTime");
			String designation=request.getParameter("designation");
			BusPassRequestBean reqBean=new BusPassRequestBean();
			reqBean.setEmployeeid(employeeid);
			reqBean.setFirstname(firstname);
			reqBean.setLastname(lastname);
			reqBean.setGender(gender);
			reqBean.setAddress(address);
			reqBean.setEmail(email);
			reqBean.setPickUpLoc(pickUpLoc);
			reqBean.setLocation(location);
			String[] datepart = doj.split("/");
			LocalDate dateOfJoin=LocalDate.of(Integer.parseInt(datepart[2]),Integer.parseInt(datepart[0]), Integer.parseInt(datepart[1]));
			reqBean.setDoj(dateOfJoin);
			
			String[] timepart = doj.split(":");
			LocalTime pickuptime=LocalTime.of(Integer.parseInt(timepart[2]),Integer.parseInt(timepart[0]), Integer.parseInt(timepart[1]));
			reqBean.setPickUpTime(pickuptime);
			reqBean.setDesignation(designation);
	
	}
	

}


