package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.model.LoginBean;

public class LoginDaoImp implements ILoginDao {
	
	
	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		String sql="select *from adminLogin where userName=? and passWord=?";
		
		try(PreparedStatement pst=getDBConnectio().prepareStatement(sql);){
			pst.setString(1, loginBean.getUserName());
			pst.setString(2, loginBean.getPassWord());
			System.out.println(loginBean.getPassWord());
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				
				return true;}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public Connection getDBConnectio() throws SQLException {
		Connection con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
		
	}
}
