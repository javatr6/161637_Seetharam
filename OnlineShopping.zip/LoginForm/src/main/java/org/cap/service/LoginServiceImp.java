package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImp;
import org.cap.model.LoginBean;

public class LoginServiceImp implements ILoginService {

	private ILoginDao loginDao=new LoginDaoImp();

	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		if(loginDao.isValidLogin(loginBean))
			return true;
		return false;
	}
	

}
