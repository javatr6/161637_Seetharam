package com.capgemini.services;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.capgemini.dao.IProductDao;
import com.capgemini.dao.ProductImp;
import com.capgemini.model.Product;


@Path("/api")
public class MyRestServices {

	private IProductDao iproductDao=new ProductImp();
	
		
			@GET
			@Path("/products")
			@Produces(MediaType.APPLICATION_JSON)
			public List<Product> getAllProducts(){
				List<Product> products=iproductDao.getAllProducts();
				return products;
			}
			
			@DELETE
			@Path("/delproducts/{productId}")
			@Produces(MediaType.APPLICATION_JSON)
			public List<Product> deleteProducts(@PathParam("productId")Integer productId){
				List<Product> products=iproductDao.deleteProducts(productId);
				
				return products;
			}
			
			@POST
			@Path("/addproducts")
			@Produces(MediaType.APPLICATION_JSON)
			public List<Product> addProducts(@PathParam("productId")Integer productId,
					@FormParam("productName") String productName){
				
				
				List<Product> products=iproductDao.addProducts(productId,productName);
				
				
				return products;
			}
			
			@PUT
			@Path("findproducts/{productId}")
			@Produces(MediaType.APPLICATION_JSON)
			public Product findProducts(@PathParam("productId") Integer productId){
				Product products = iproductDao.findProducts(productId);
				return products;
			} 
			
			@GET
			@Path("/hello")
			public String sayHello() {
				return "Hello world!! from REST API";
				
			}
			
			@GET
			@Path("/greet/{userName}")
			@Produces(MediaType.TEXT_HTML)
			public String greetUser(@PathParam("userName")String myUser) {
				return "<h1 style='color:red;'>Hello "+myUser+"</h1>";
				
			}
			@GET
			@Path("/loaddata")
			@Produces(MediaType.TEXT_HTML)
			public String getXML() {
				return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
						+"<employee>"
						+"<firstName>Rohit </firstName>"
						+"<lastName>Sharma </lastName>"
						+"<age> 31 </age>"
						+"</employee>";
			}
			
			@GET
			@Path("/loadjson")
			@Produces(MediaType.APPLICATION_JSON)
			public String getJSON() {
				return "{"
						+ "\"firstname\":\"darren\","
						+"\"lastname\":\"samy\","
						+"\"age\":\"26\""
						+ "}";
			}
			
			
			@POST
			@Path("updateproducts/{productId}/{productName}")
			@Produces(MediaType.APPLICATION_JSON)
			public List<Product> updateProducts(@PathParam("productId") Integer productId,@PathParam("productName")String productName){
				List<Product> products = iproductDao.updateProducts(productId,productName);
				return products;
			} 
			

		} 
		 

